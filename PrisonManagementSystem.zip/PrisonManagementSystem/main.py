import pymysql
from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk

#connection for phpmyadmin
def connection():
    conn = pymysql.connect(
        host='localhost',
        user='root', 
        password='',
        db='prison',
    )
    return conn


def refreshTable():
    for data in my_tree.get_children():
        my_tree.delete(data)

    for array in read():
        my_tree.insert(parent='', index='end', iid=array, text="", values=(array), tag="orow")

    my_tree.tag_configure('orow', background="#7D7D7D", font=('Arial', 9,"bold"))
    my_tree.grid(row=15, column=0, columnspan=7, rowspan=1, padx=5, pady=5)



root = Tk()
root.title("Prison Management System")
root.geometry("1540x800")
my_tree = ttk.Treeview(root)


#placeholders for entry
ph1 = tk.StringVar()
ph2 = tk.StringVar()
ph3 = tk.StringVar()
ph4 = tk.StringVar()
ph5 = tk.StringVar()
ph6 = tk.StringVar()
ph7 = tk.StringVar()
ph8 = tk.StringVar()
ph9 = tk.StringVar()
ph10 = tk.StringVar()
ph11 = tk.StringVar()
ph12 = tk.StringVar()
ph13 = tk.StringVar()


#placeholder set value function
def setph(word,num):
    if num ==1:
        ph1.set(word)
    if num ==2:
        ph2.set(word)
    if num ==3:
        ph3.set(word)
    if num ==4:
        ph4.set(word)
    if num ==5:
        ph5.set(word)
    if num ==6:
        ph6.set(word)
    if num ==7:
        ph7.set(word)
    if num ==8:
        ph8.set(word)
    if num ==9:
        ph9.set(word)
    if num ==10:
        ph10.set(word)
    if num ==11:
        ph11.set(word)
    if num ==12:
        ph12.set(word)
    if num ==13:
        ph13.set(word)


def read():
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM prisoners")
    results = cursor.fetchall()
    conn.commit()
    conn.close()
    return results

def add():
    Pnic = str(PnicEntry.get())
    Pname = str(PnamEntry.get())
    Pdop = str(PdopEntry.get())
    Pemail = str(PemailEntry.get())
    Pnum = str(PnumEntry.get())
    Paddress = str(PaddressEntry.get())
    Gname = str(GnameEntry.get())
    Gnic = str(GnicEntry.get())
    Gnum = str(GnumEntry.get())
    Lname = str(LnameEntry.get())
    Lid = str(LidEntry.get())
    Lnic = str(LnicEntry.get())
    Lnum = str(LnumEntry.get())
  

    if (Pnic== "" or Pnic== " ") or (Pname== "" or Pname== " ") or (Pdop== "" or Pdop== " ") or (Pemail== "" or Pemail== " ") or (Pnum== "" or Pnum== " ")or (Paddress== "" or Paddress== " ") or (Gname== "" or Gname== " ") or (Gnic== "" or Gnic== " ") or (Gnum== "" or Gnum== " ")or (Lname== "" or Lname== " ") or (Lid== "" or Lid== " ") or (Lnic== "" or Lnic== " ") or (Lnum== "" or Lnum== " "):
        messagebox.showinfo("Error", "Please fill up the blank entry")
        return
    else:
        try:
            conn = connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO prisoners VALUES ('"+Pnic+"','"+Pname+"','"+Pdop+"','"+Pemail+"','"+Pnum+"','"+Paddress+"','"+Gname+"','"+Gnic+"','"+Gnum+"','"+Lname+"','"+Lid+"','"+Lnic+"','"+Lnum+"') ")
            conn.commit()
            conn.close()
        except:
            messagebox.showinfo("Error", "Prisoner NIC already exist")
            return

    refreshTable()

def reset():
    decision = messagebox.askquestion("Warning!!", "Delete all data?")
    if decision != "yes":
      
        return 
    else:
        try:
            conn = connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM prisoners")
            conn.commit()
            conn.close()
            
        except:
            messagebox.showinfo("Error", "Sorry an error occured")
            return

        refreshTable()

def delete():
    decision = messagebox.askquestion("Warning!!", "Delete the selected data?")
    if decision != "yes":
        return 
    else:
        selected_item = my_tree.selection()[0]
        deleteData = str(my_tree.item(selected_item)['values'][0])
        
        try:
            conn = connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM prisoners WHERE Pnic='"+str(deleteData)+"'")
            conn.commit()
            conn.close()
        except:
            messagebox.showinfo("Error", "Sorry an error occured")
            return

        refreshTable()

def select():
    try:
        selected_item=my_tree.selection()[0]
        Pnic=str(my_tree.item(selected_item)['values'][0])
        Pname=str(my_tree.item(selected_item)['values'][1])
        Pdop=str(my_tree.item(selected_item)['values'][2])
        Pemail=str(my_tree.item(selected_item)['values'][3])
        Pnum=str(my_tree.item(selected_item)['values'][4])
        Paddress=str(my_tree.item(selected_item)['values'][5])
        Gname=str(my_tree.item(selected_item)['values'][6])
        Gnic=str(my_tree.item(selected_item)['values'][7])
        Gnum=str(my_tree.item(selected_item)['values'][8])
        Lname=str(my_tree.item(selected_item)['values'][9])
        Lid=str(my_tree.item(selected_item)['values'][10])
        Lnic=str(my_tree.item(selected_item)['values'][11])
        Lnum=str(my_tree.item(selected_item)['values'][12])

        setph(Pnic,1)
        setph(Pname,2)
        setph(Pdop,3)
        setph(Pemail,4)
        setph(Pnum,5)
        setph(Paddress,6)
        setph(Gname,7)
        setph(Gnic,8)
        setph(Gnum,9)
        setph(Lname,10)
        setph(Lid,11)
        setph(Lnic,12)
        setph(Lnum,13)
        
    except:
        messagebox.showinfo("Error", "Please select a data row")


def search():
    Pnic=str(PnicEntry.get())
    Pname=str(PnamEntry.get())
    Pdop=str(PdopEntry.get())
    Pemail=str(PemailEntry.get())
    Pnum=str(PnumEntry.get())
    Paddress=str(PaddressEntry.get())
    Gname=str(GnameEntry.get())
    Gnic=str(GnicEntry.get())
    Gnum=str(GnumEntry.get())
    Lname=str(LnameEntry.get())
    Lid=str(LidEntry.get())
    Lnic=str(LnicEntry.get())
    Lnum=str(LnumEntry.get())

    conn=connection()
    cursor=conn.cursor()
    cursor.execute("SELECT * FROM prisoners WHERE Pnic='"+
    Pnic+"' or Pname='"+
    Pname+"' or Pdop='"+
    Pdop+"' or Pemail='"+
    Pemail+"' or Pnum='"+
    Pnum+"' or Paddress='"+
    Paddress+"' or Gname='"+
    Gname+"' or Gnic='"+
    Gnic+"' or Gnum='"+
    Gnum+"' or Lname='"+
    Lname+"' or Lid='"+
    Lid+"' or Lnic='"+
    Lnic+"' or Lnum='"+
    Lnum+"' ")
    
    try:
        result=cursor.fetchall()

        for num in range(0,13):
            setph(result[0][num],(num+1))

        conn.commit()
        conn.close()
    except:
        messagebox.showinfo("Error", "No data found")


def update():
    selectedPnic= ""
    try:
        selected_item=my_tree.selection()[0]
        selectedPnic=str(my_tree.item(selected_item)['values'][0])
    except:
        messagebox.showinfo("Error", "Please select a data row")

    Pnic=str(PnicEntry.get())
    Pname=str(PnamEntry.get())
    Pdop=str(PdopEntry.get())
    Pemail=str(PemailEntry.get())
    Pnum=str(PnumEntry.get())
    Paddress=str(PaddressEntry.get())
    Gname=str(GnameEntry.get())
    Gnic=str(GnicEntry.get())
    Gnum=str(GnumEntry.get())
    Lname=str(LnameEntry.get())
    Lid=str(LidEntry.get())
    Lnic=str(LnicEntry.get())
    Lnum=str(LnumEntry.get())

    if (Pnic=="" or Pnic==" ") or (Pname=="" or Pname==" ") or (Pdop=="" or Pdop==" ") or (Pemail=="" or Pemail==" ") or (Pnum=="" or Pnum==" ")or (Paddress=="" or Paddress==" ") or (Gname=="" or Gname==" ") or (Gnic=="" or Gnic==" ") or (Gnum=="" or Gnum==" ")or (Lname=="" or Lname==" ") or (Lid=="" or Lid==" ") or (Lnic=="" or Lnic==" ") or (Lnum== "" or Lnum== " "):
        messagebox.showinfo("Error", "Please fill up the blank entry")
        return
    else:
        try:
            conn=connection()
            cursor=conn.cursor()
            cursor.execute("UPDATE prisoners SET Pnic='"+
            Pnic+"' , Pname='"+
            Pname+"', Pdop='"+
            Pdop+"' , Pemail='"+
            Pemail+"' Pnum='"+
            Pnum+"' , Paddress='"+
            Paddress+"' , Gname='"+
            Gname+"' , Gnic='"+
            Gnic+"' , Gnum='"+
            Gnum+"' , Lname='"+
            Lname+"' , Lid='"+
            Lid+"' , Lnic='"+
            Lnic+"' , Lnum='"+
            Lnum+"'WHERE Pnic='"+
            selectedPnic+"' ")
            conn.commit()
            conn.close()
        except:
            messagebox.showinfo("Error", "Prisoner NIC already exist")
            return

    refreshTable()


label=Label(root,text="Prison Management System", font=('Arial bold', 30))
label.grid(row=0, column=1, columnspan=5, rowspan=1, padx=5, pady=5)

PnicLabel = Label(root, text="Prisoner NIC", font=('Arial', 10,"bold"))
PnameLabel = Label(root, text="Prisoner Name", font=('Arial', 10,"bold"))
PdopLabel = Label(root, text="Prisoner DOP", font=('Arial', 10,"bold"))
PemailLabel = Label(root, text="Prisoner Email", font=('Arial', 10,"bold"))
PnumLabel = Label(root, text="Prisoner PN", font=('Arial', 10, "bold"))
PaddressLabel = Label(root, text="Prisoner Address", font=('Arial', 10,"bold"))
GnameLabel = Label(root, text="Guidance Name", font=('Arial', 10,"bold"))
GnicLabel = Label(root, text="Guidance NIC", font=('Arial', 10,"bold"))
GnumLabel = Label(root, text="Guidance PN", font=('Arial', 10,"bold"))
LnameLabel = Label(root, text="Lawyer Name", font=('Arial', 10,"bold"))
LidLabel = Label(root, text="Lawyer ID", font=('Arial', 10,"bold"))
LnicLabel = Label(root, text="Lawyer NIC", font=('Arial', 10,"bold"))
LnumLabel = Label(root, text="Lawyer PN", font=('Arial', 10,"bold"))


PnicLabel.grid(row=2, column=0, columnspan=1, padx=2, pady=6)
PnameLabel.grid(row=4, column=0, columnspan=1, padx=2, pady=6)
PdopLabel.grid(row=6, column=0, columnspan=1, padx=2, pady=6)
PemailLabel.grid(row=8, column=0, columnspan=1, padx=2, pady=6)
PnumLabel.grid(row=10, column=0, columnspan=1, padx=2, pady=6)
PaddressLabel.grid(row=12, column=0, columnspan=1, padx=2, pady=6)
GnameLabel.grid(row=5, column=2, columnspan=1, padx=2, pady=6)
GnicLabel.grid(row=7, column=2, columnspan=1, padx=2, pady=6)
GnumLabel.grid(row=9, column=2, columnspan=1, padx=2, pady=6)
LnameLabel.grid(row=4, column=4, columnspan=1, padx=2, pady=6)
LidLabel.grid(row=6, column=4, columnspan=1, padx=2, pady=6)
LnicLabel.grid(row=8, column=4, columnspan=1, padx=2, pady=6)
LnumLabel.grid(row=10, column=4, columnspan=1, padx=2, pady=6)




PnicEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph1)
PnamEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph2)
PdopEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph3)
PemailEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph4)
PnumEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph5)
PaddressEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph6)
GnameEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph7)
GnicEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph8)
GnumEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph9)
LnameEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph10)
LidEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph11)
LnicEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph12)
LnumEntry =Entry(root, width=20, bd=5, font=('Arial', 15), textvariable = ph13)



PnicEntry.grid(row=2, column=1, columnspan=1, padx=2, pady=0)
PnamEntry.grid(row=4, column=1, columnspan=1, padx=2, pady=0)
PdopEntry.grid(row=6, column=1, columnspan=1, padx=2, pady=0)
PemailEntry.grid(row=8, column=1, columnspan=1, padx=2, pady=0)
PnumEntry.grid(row=10, column=1, columnspan=1, padx=2, pady=0)
PaddressEntry.grid(row=12, column=1, columnspan=1, padx=2, pady=0)
GnameEntry.grid(row=5, column=3, columnspan=1, padx=2, pady=0)
GnicEntry.grid(row=7, column=3, columnspan=1, padx=2, pady=0)
GnumEntry.grid(row=9, column=3, columnspan=1, padx=2, pady=0)
LnameEntry.grid(row=4, column=5, columnspan=1, padx=2, pady=0)
LidEntry.grid(row=6, column=5, columnspan=1, padx=2, pady=0)
LnicEntry.grid(row=8, column=5, columnspan=1, padx=2, pady=0)
LnumEntry.grid(row=10, column=5, columnspan=1, padx=2, pady=0)


addBtn=Button(
    root, text="Add", padx=2, pady=6, width=14,
    bd=5, font=('Arial', 15,"bold"), bg="#FFA500", command=add)
updateBtn=Button(
    root, text="Update", padx=2, pady=6, width=14,
    bd=5, font=('Arial', 15,"bold"), bg="#9ACD32", command=update)
deleteBtn=Button(
    root, text="Delete", padx=2, pady=6, width=14,
    bd=5, font=('Arial', 15,"bold"), bg="#CD0000", command=delete)
searchBtn=Button(
    root, text="Search", padx=2, pady=6, width=14,
    bd=5, font=('Arial', 15,"bold"), bg="#00868B", command=search)
resetBtn=Button(
    root, text="Reset", padx=2, pady=6, width=14,
    bd=5, font=('Arial', 15,"bold"), bg="#D02090", command=reset)
selectBtn=Button(
    root, text="Select", padx=2, pady=6, width=14,
    bd=5, font=('Arial', 15,"bold"), bg="#68228B", command=select)
   

addBtn.grid(row=25, column=0, columnspan=1, rowspan=1)
updateBtn.grid(row=25, column=1, columnspan=1, rowspan=1)
deleteBtn.grid(row=25, column=2, columnspan=1, rowspan=1)
searchBtn.grid(row=25, column=3, columnspan=1, rowspan=1)
resetBtn.grid(row=25, column=4, columnspan=1, rowspan=1)
selectBtn.grid(row=25, column=5, columnspan=1, rowspan=1)

style = ttk.Style()
style.configure("Treeview.Heading", font=('Arial Bold', 10))

my_tree['columns'] = ("Prisoner NIC","Prisoner Name","Prisoner DOP","Prisoner Email","Prisoner PN","Prisoner Address","Guidance Name","Guidance NIC","Guidance PN","Lawyer Name","Lawyer ID","Lawyer NIC","Lawyer PN")

my_tree.column("#0", width=0, stretch=NO)
my_tree.column("Prisoner NIC", anchor=W, width=98)
my_tree.column("Prisoner Name", anchor=W, width=98)
my_tree.column("Prisoner DOP", anchor=W, width=98)
my_tree.column("Prisoner Email", anchor=W, width=98)
my_tree.column("Prisoner PN", anchor=W, width=98)
my_tree.column("Prisoner Address", anchor=W, width=98)
my_tree.column("Guidance Name", anchor=W, width=98)
my_tree.column("Guidance NIC", anchor=W, width=98)
my_tree.column("Guidance PN", anchor=W, width=98)
my_tree.column("Lawyer Name", anchor=W, width=98)
my_tree.column("Lawyer ID", anchor=W, width=98)
my_tree.column("Lawyer NIC", anchor=W, width=98)
my_tree.column("Lawyer PN", anchor=W, width=98)



my_tree.heading("Prisoner NIC", text="PNIC", anchor=W )
my_tree.heading("Prisoner Name", text="PName", anchor=W)
my_tree.heading("Prisoner DOP", text="PDOP", anchor=W)
my_tree.heading("Prisoner Email", text="PEmail", anchor=W)
my_tree.heading("Prisoner PN", text="PPN", anchor=W)
my_tree.heading("Prisoner Address", text="PAddress", anchor=W)
my_tree.heading("Guidance Name", text="GName", anchor=W)
my_tree.heading("Guidance NIC", text="GNIC", anchor=W)
my_tree.heading("Guidance PN", text="GPN", anchor=W)
my_tree.heading("Lawyer Name", text="LName", anchor=W)
my_tree.heading("Lawyer ID", text="LID", anchor=W)
my_tree.heading("Lawyer NIC", text="LNIC", anchor=W)
my_tree.heading("Lawyer PN", text="LPN", anchor=W)

refreshTable()


root.mainloop()